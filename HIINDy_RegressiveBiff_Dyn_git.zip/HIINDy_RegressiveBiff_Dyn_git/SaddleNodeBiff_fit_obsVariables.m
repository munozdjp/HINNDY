%generation of data
close all,clear all, clc
figpath = '../figures/';
addpath('./utils');
%delta time
dt=0.1; 
%coefficient of polinomial
a=3;
b=2;
c=1;
polytime=[a b c];
interval=[-0 10];
time=(interval(2):-dt:interval(1));
%Beta data generated in a poly order 3
mu_span=time*polytime(1)+time.^2*polytime(2)+c*time.^3;

%% Generation of alpha parameter from observations

c=[3,2,1];
y=c(1)*(time)+c(2)*(time).^2+c(3)*(time).^3;

xpoints=real(sqrt(mu_span));
mu_predicted= xpoints.^2;

%% Fitting the beta observed into a polinomial dynamic.
%Define the funciton to fit
F1=@(weightdx,xdata) xdata*weightdx(1)+xdata.^2*weightdx(2)+xdata.^3*weightdx(3);
%Initial guess for the coeficients at+bt^2+ct^3
weights0=[0.5 0.5 0.5];
%curve fitting tool
[weightdx, resnorm,~,exitflag,output]=lsqcurvefit(F1,weights0, time, mu_predicted)

reproduced_data= F1(weightdx,time);

figure(1)
plot(time,y,'r-')
xlabel('time')
ylabel('alpha parameter')
hold on
xline(0,'k--');
set(gca,'FontSize',16);
l=legend('Explicit polinomial for steady state generation','implicit polinmial for ODE data generation');
l.FontSize = 14;
l.Location='northeast';
title('Dynamic of the hidden variable alpha = 3 + 2*t + t^2');
hold off


figure(2)
plot(mu_span ,xpoints, 'r*' )
xlabel('alpha values monotonic increasing','FontSize',16)
ylabel('Observations of the system ','Fontsize',16)
legend('Observation of the system with variations of alpha', 'FontSize' , 16 )
axis([-0 1200 -0 40]);
title('Alpha parameter changing with increasing values from (left to right) vs observations of the system','FontSize',16)

figure(3)
plot(time,mu_span, 'k--','LineWidth', 1)
hold on
plot(time,reproduced_data, 'r-');
xline(0);
set(gca,'FontSize',16);
l=legend('True alpha ','Recovered alpha dynamic using HINNDy');
l.FontSize = 14;
l.Location='southeast';
title('Alpha Values: True dynamic vs Discovered dynamic using HINNDy')