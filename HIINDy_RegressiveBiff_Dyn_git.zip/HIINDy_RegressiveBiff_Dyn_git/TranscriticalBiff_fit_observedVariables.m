%generation of data
clc, clear all,close all 
dt=0.1; %delta time
%coefficient of polinomial
a=3;
b=2;
c=10;
polytime=[a b c];
%time interval for prediction
intervalraw=[-10 5];
time1=(intervalraw(2):-dt:0);
time2 = [0:-dt:intervalraw(1)]
time = [time1,zeros(1,length(time2)-1)]
timereal = [intervalraw(2):-dt:intervalraw(1)]

%Prediction of the data. 
mu_span = time*polytime(1)+time.^2*polytime(2)+c*time.^3;
xpoints = mu_span;% create a new time span 
xObserved = xpoints;
mu_predicted = xObserved;

%% Fitting the beta observed into a polinomial dynamic.

%Define the funciton to fit
F1=@(weightdx,xdata) xdata*weightdx(1)+xdata.^2*weightdx(2)+xdata.^3*weightdx(3);
%Initial guess for the coeficients at+bt^2+ct^3
weights0=[0.5 0.5 0.5];
%curve fitting tool
[weightdx, resnorm,~,exitflag,output]=lsqcurvefit(F1,weights0, timereal, mu_predicted)

%Plot beta from: Polinomial fit vs steady state equation
reproduced_data= F1(weightdx,timereal);
figure(1)
plot(timereal,mu_span)
hold on
plot(timereal,reproduced_data);
xline(0,'k--');
set(gca,'FontSize',16);
l=legend('Beta from steady state equations','Predicted Beta from fitting curve');
l.FontSize = 14;
l.Location='southeast';
title('Beta from: Polinomial fit vs steady state equation')
%F1=@(weightdx,xdata) xdata(:,4) - xdata(:,1).^2 + weightdx(1)*xdata(:,2)...
 %   + weightdx(2)*xdata(:,3) ;