clear all, close all, clc
figpath = '../figures/';
addpath('./utils');

omega = 1;
A = 1;
%Number of variables
n = 4;

dt=0.001; %timestep
% Integrate interval
Initinterval = 16;
neg_inter = 0;
tinterval=[neg_inter Initinterval];
tspan2=[tinterval(2):-dt:tinterval(1)]; %interval for solving the 
tspan=[.001:dt:tinterval(2)-tinterval(1)];
N = length(tspan);
options = odeset('RelTol',1e-12,'AbsTol',1e-12*ones(1,n));
X=[];
%Coeficients of polyorder 3 c1*t+c2*t^2+c3*t^3 & and final time value 
c=[1,1,1,Initinterval];
%Analitic polinomial
y=c(1)*(tspan2)+c(2)*(tspan2).^2+c(3)*(tspan2).^3;
%inverted polinomial
y2=c(1)*(-tspan+tinterval(2) )+c(2)*(-tspan...
    +tinterval(2)).^2+c(3)*(-tspan+tinterval(2)).^3;
%plot of inverted polinomial
figure(1)
plot(tspan2,y,'r-',tspan,y2,'b--')
xlabel('time')
ylabel('beta parameter')
hold on
xline(0,'k--');
set(gca,'FontSize',16);
l=legend('Explicit polinomial for steady state generation','implicit polinmial for ODE data generation');
l.FontSize = 14;
l.Location='northeast';
title('Inverted polinomial');
%Integration of hopf system
i=0;
for traslation=[0];
    i=i+1;
for mu0=[y2(1)]    ;
    %x0=sqrt(y2(1)/2) %Formula of radius of Initial Condition
    for x0=sqrt(y2(1)/2)+traslation%Formula of radius of Initial Condition
        [t,x] = ode45(@(t,x) hopfPolyOrder3(t,x,c,omega,A,traslation),tspan,[tspan(1),mu0,x0,x0],options);
         X = [X;x];
         %Variable x3 vs bifurcation parameter
            figure(2)
            hold on
            plot(x(:,2),x(:,3),'b-')
            xlabel('Beta')
            ylabel('x_3')
            xline(0,'k--');
            set(gca,'FontSize',16);
            l=legend('Trajectory using numerical integration');
            l.FontSize = 14;
            l.Location='northeast';
            title('State variable vs Biffurcation parameter')
            hold off    
    end
end
xtrajectories(:,i)=[x(:,3)];
end
%Mu observed from equations of steady state
mu_observed=(x(:,4)+x(:,3).*(x(:,3).^2+x(:,4).^2))./x(:,3);


%% polinomial fit

%Define the function to fit: "Poly order 2"
F1=@(weightdx,time) (-time+tinterval(2))...
    *weightdx(1)+(-time+tinterval(2)).^2*weightdx(2)+(-time+tinterval(2)).^3*weightdx(3);
%curve fitting
weights0=[0.5 0.5 0.5]; %initial guess for weights
[weightdx, resnorm,~,exitflag,output] = lsqcurvefit(F1,weights0, tspan, mu_observed')

%data predicted from F1 evaluated with the predicted coefficients
reproduced_data= F1(weightdx,tspan);


%plot of beta: real VS polinomial fit VS steady equations
figure(3)
plot(tspan,y2,'r-','LineWidth',1)%real dynamic
yline(0,'k--','HandleVisibility','off');
hold on
plot(tspan,reproduced_data,'b--','LineWidth',1); %Beta from polinomial fit
plot(tspan,mu_observed,'m-')%,'LineWidth',1) %Beta from steady equations
xlabel('Time')
ylabel('Beta')
axis([0 20 -100 5000])
set(gca,'FontSize',16);
l=legend('Real Beta ','Predicted Beta:With Polinomial weights','Observed Beta from steady state equations ');
l.FontSize = 14;
l.Location='northeast';
title('Beta from: real dynamic, polinomial fit, Observed from steady equations')
hold off