
clear all, close all, clc
figpath = '../figures/';
addpath('./utils');
tic
%% generate Data
%Noise scale
noise_scale=0;
n = 3;%number of variables
dt=0.01;%timestep
%Integrate interval

Initinterval = 16; %initial value of the pitchfor bifurcation

%real hidden variable interval
tinterval=[-4 Initinterval];




% Integrate
tspan2=[tinterval(2):-dt:tinterval(1)]; %interval for solving the 
tspan=[.001:dt:tinterval(2)-tinterval(1)];
N = length(tspan);
options = odeset('RelTol',1e-12,'AbsTol',1e-12*ones(1,n));
X=[];
%Coeficients of polyorder 3 c1*t+c2*t^2+c3*t^3 & and final time value 
c=[3,2,1,Initinterval];
%Analitic polinomial
y=c(1)*(tspan2)+c(2)*(tspan2).^2+c(3)*(tspan2).^3;
%inverted polinomial
y2=c(1)*(-tspan+tinterval(2) )+c(2)*(-tspan...
    +tinterval(2)).^2+c(3)*(-tspan+tinterval(2)).^3;
%plot of inverted polinomial
figure(1)
plot(tspan2,y,'r-',tspan,y2,'b--')
hold on
xline(0,'k--');
set(gca,'FontSize',16);
l=legend('Explicit polinomial for steady state generation','implicit polinmial for ODE data generation');
l.FontSize = 14;
l.Location='northeast';
title('Inverted polinomial');
%Integration for Pitchforksystem
for mu0=[y2(1)]  %initial condition of Beta  
    %sqrt(muo)%formula of coordinate x0 in function of beta(mu0)
    for x0=real(sqrt(mu0))%Initial condition of state variables
        [t,x] = ode45(@(t,x) pitchforkPolyorder3(t,x,c),tspan,[tspan(1),mu0,x0],options);
         X = [X;x];
         %plot variable x vs bifurcation parameter
            figure(2)
            hold on
            plot(x(:,2),x(:,3),'b-')    
            xline(0,'k--');
            yline(0,'k--');
            set(gca,'FontSize',16);
            l=legend('Trajectory using numerical integration');
            l.FontSize = 14;
            l.Location='northeast';
            title('State variable vs Biffurcation parameter')
            hold off    
    end
end
%Mu extracted from from numerical integration
ss=size(x(:,3));
Noise=noise_scale*randn(ss);% Generates Noise
%Mu observed from equations of steady state
mu_observed=((x(:,3).^2)+Noise)'; 

%% polinomial fit
%Define the function to fit: "Poly order 2"
F1=@(weightdx,xdata) (-xdata+tinterval(2))...
    *weightdx(1)+(-xdata+tinterval(2)).^2*weightdx(2)+(-xdata+tinterval(2)).^3*weightdx(3);

%curve fitting
weights0=[0.5 0.5 0.5];%initial guess for weights
[weightdx, resnorm,~,exitflag,output] = lsqcurvefit(F1,weights0, tspan, mu_observed)

%data predicted from F1 evaluated with the predicted coefficients
reproduced_data= F1(weightdx,tspan);

%plot of beta: real VS polinomial fit VS steady equations
figure(3)
plot(tspan,y2,'r-','LineWidth',1)
yline(0,'k--','HandleVisibility','off');
hold on
plot(tspan,reproduced_data,'b--','LineWidth',1); %Beta from polinomial fit
plot(tspan,mu_observed,'m-')%,'LineWidth',1) %Beta from steady equations
axis([13 20 -60 80])
set(gca,'FontSize',16);
l=legend('Real Beta ','Predicted Beta:With Polinomial weights','Observed Beta from steady state equations ');
l.FontSize = 14;
l.Location='northeast';
title('Beta from: real dynamic, polinomial fit, Observed from steady equations')
hold off
